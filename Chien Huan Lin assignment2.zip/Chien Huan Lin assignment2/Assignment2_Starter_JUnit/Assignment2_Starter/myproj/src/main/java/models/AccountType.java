package models;

public enum AccountType {
   checkings, savings, fixed
}
